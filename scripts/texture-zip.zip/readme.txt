databáze by sama mohla rozhodnout zda použije první nebo druhý skript - závisí to na datu vytvoření textury - jestli byla vytvořena před nebo po 4.3.2026

může se podívat do složky xK (4K, 8K …) a dle data změny určit který použije