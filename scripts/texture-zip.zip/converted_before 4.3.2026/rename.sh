#!/bin/bash

# Cesty k programum, ktere se budou pouzivat
# Misto C:/neco/neco je potreba pouzivat obracena lomitka
IMAGEMAGICK_PATH="/c/Program Files/ImageMagick-7.1.1-Q16-HDRI/magick.exe"
ZIP_PATH="/c/ProgramData/chocolatey/lib/zip/tools/zip.exe"
error=0

if [ ! -f "${IMAGEMAGICK_PATH}" ]; then
    echo "Cesta k programu Imagemagick je neplatná, je nutné upravit skript."
    error=1
fi

if [ ! -f "${ZIP_PATH}" ]; then
    echo "Cesta k programu zip je neplatná, je nutné upravit skript."
    error=1
fi

if [[ ! -d "$1" || ! -d "$2" ]]; then
    echo "Je třeba zadat cestu ke zdrojové a cílové složce:"
    echo "    $0 /c/cesta/ke/zdroji/ /c/cesta/k/cili/"
    echo "Obě složky musí existovat. Cesta musí končit lomítkem."
    error=1
fi

if [[ ! "$1" == */  || ! "$2" == */ ]]; then
    echo "Je třeba zadat cestu ke zdrojové a cílové složce:"
    echo "    $0 /c/cesta/ke/zdroji/ /c/cesta/k/cili/"
    echo "Obě složky musí existovat. Cesta musí končit lomítkem."
    error=1
fi

if [ $error -eq 1 ]; then
    exit 1
fi

# Samotny program

function genMetadata() {
    echo "{"
    echo "    \"WEB_APP_PART\": {"
    echo "        \"TEXTURE_RESOLUTIONS\": {"
    first=1
    ratio=""
    for i in $(find . -type d -name '*K'); do
        if [ ! $first -eq 1 ]; then 
            echo ","
        fi
        first=0
        folder=$(basename "$i")
        file=$(find "${folder}" -name '*.jpg' -or -name '*.jpeg' | head -n1)
        res=$("${IMAGEMAGICK_PATH}" identify -quiet -format "%[fx:w]x%[fx:h]" "${file}")
        echo -n "            \"$folder\": \"$res\""
        if [ "$ratio" == "" ]; then
            ratio=$("${IMAGEMAGICK_PATH}" identify -quiet -format "%[fx:h]/%[fx:w]" "${file}")
        fi
    done
    echo ""
    echo "        },"
    echo "        \"IMAGE_RATIO\": "$(awk "BEGIN { print ($ratio) }")","
    echo "        \"MAPS_SHORTCUTS\": ["
    first=1
    for i in $(find 1K -name '*.jpg' -or -name '*.jpeg' -or -name '*.tif' -or -name '*.tiff' | sort | uniq ); do 
        if [ ! $first -eq 1 ]; then 
            echo ","
        fi
        first=0
        echo -n "            \""$(cut -d_ -f4 <<<"$i")"\""
    done
    echo ""
    echo "        ]"
    echo "    },"
    echo "    \"DESKTOP_APP_PART\": {"

    echo "    },"
    echo "}"
}

echo "" > "$2/operations.txt"
logPath=$(realpath "$2/operations.txt")
origPathLength=${#1}
resultPathLength=${#2}

# Precist COL, vzit rozliseni
# pokud je mensi nez nasobek 1024, tak s tim pracovat jako s nizsim rozlisenim (13K -> 12K)
# A potom vzit tif z RES slozky (muze byt i v root slozce)

# Dulezite parametry: bitova hloubka, color profile (identify -verbose yourimage)

# Projde zadanou zdrojovou slozku a najde vsechny slozky, ktere se jmenuji [0-9][0-9]*K (regex)
IFS=$'\n' find "$1" -type d -regextype sed -regex ".*/[0-9][0-9]*K" | while read respath; do
    #promenna respath obsahuje cestu ke zdrojove slozce se soucasnym rozlisenim
    origResolution=$(basename "${respath}")
    fullInnerPath=$(dirname "${respath}")
    innerPath=$(cut -c $origPathLength- <<< "$fullInnerPath")
    if [[ "$innerPath" == "" ]]; then
        innerPath=$(basename "$fullInnerPath")
    fi
    
    # vytvori pracovni slozku v cilove slozce
    mkdir -p "$2/${innerPath}"
    echo "Working on ${fullInnerPath}"

    find "$respath" -type f -maxdepth 1 | while read file; do
        type=$(basename "$file" | cut -d_ -f4)
        if [[ "$type" == "COL" ]]; then
            echo -n "Preprocess... "

            eval $("${IMAGEMAGICK_PATH}" identify -quiet -format "originalWidth=%[fx:h]\noriginalHeight=%[fx:w]" "${file}")
            
            expectedPixels=$((1024*${origResolution/K/}))
            if [[ "$originalWidth" -gt "$expectedPixels" || "$originalHeight" -gt "$expectedPixels" ]]; then
                echo "$innerPath is larger than expected (${originalWidth}x${originalHeight} vs ${expectedPixels}x${expectedPixels})"
                sourceResolution=${origResolution}
                pixels=$((1024*${sourceResolution/K/}))
                mkdir -p "$2/${innerPath}/$sourceResolution"
                find "$respath" -type f | while read sourceImage; do
                    sourceImageRes=$(basename "$sourceImage" | cut -d_ -f5 | cut -d. -f1)
                    if [[ "$sourceImageRes" == "$origResolution" ]]; then
                        convertedImage=$(basename "$sourceImage" | cut -d. -f1 | cut -d_ -f-4)_${sourceResolution}.$(basename "$sourceImage" | cut -d. -f2)
                        timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${pixels}x${pixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${pixels}x${pixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || (echo "!!! ${convertedImage} did not get generated" && echo "!!! ${convertedImage} did not get generated" >> "${logPath}"); 
                    fi
                done
            elif [[ "$originalWidth" -lt "$expectedPixels" && "$originalHeight" -lt "$expectedPixels" ]]; then
                if [ "$originalWidth" -gt "$originalHeight" ]; then
                    sourceResolution=$(($originalWidth/1024))K
                else
                    sourceResolution=$(($originalHeight/1024))K
                fi
                echo "$innerPath is smaller than expected, will be treated as $sourceResolution instead of $origResolution ${originalWidth}x${originalHeight} vs ${expectedPixels}x${expectedPixels}"
                pixels=$((1024*${sourceResolution/K/}))
                mkdir -p "$2/${innerPath}/$sourceResolution"
                find "$respath" -type f | while read sourceImage; do
                    sourceImageRes=$(basename "$sourceImage" | cut -d_ -f5 | cut -d. -f1)
                    if [[ "$sourceImageRes" == "$origResolution" ]]; then
                        convertedImage=$(basename "$sourceImage" | cut -d. -f1 | cut -d_ -f-4)_${sourceResolution}.$(basename "$sourceImage" | cut -d. -f2)
                        timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${pixels}x${pixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${pixels}x${pixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || (echo "!!! ${convertedImage} did not get generated" && echo "!!! ${convertedImage} did not get generated" >> "${logPath}"); 
                    fi
                done
            else
                sourceResolution="$origResolution"
                mkdir -p "$2/${innerPath}/$sourceResolution"
                find "$respath" -type f | while read sourceImage; do
                    sourceImageRes=$(basename "$sourceImage" | cut -d_ -f5 | cut -d. -f1)
                    if [[ "$sourceImageRes" == "$origResolution" ]]; then
                        sourceImageResolution=$("${IMAGEMAGICK_PATH}" identify -quiet -format "%[fx:h]x%[fx:w]" "${sourceImage}")
                        convertedImage=$(basename "$sourceImage" | cut -d. -f1 | cut -d_ -f-4)_${sourceResolution}.$(basename "$sourceImage" | cut -d. -f2)
                        if [[ "${sourceImageResolution}" == "${expectedPixels}x${expectedPixels}" ]]; then
                            cp "${sourceImage}" "$2/${innerPath}/$sourceResolution/$convertedImage"
                        else
                            timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${expectedPixels}x${expectedPixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${sourceImage}" -resize ${expectedPixels}x${expectedPixels} "$2/${innerPath}/$sourceResolution/$convertedImage" || (echo "!!! ${newFile} did not get generated" && echo "!!! ${newFile} did not get generated" >> "${logpath}"); 
                        fi
                    fi
                done
            fi
            break
        fi
    done    

    cp -r "${fullInnerPath}/PREVIEW" "$2/${innerPath}"

    # vstoupi do nove pracovni slozky pro soucasne rozliseni
    pushd "$2/${innerPath}" >/dev/null
        sourceResolution=$(basename *K)
        for newResolution in 16 8 4 2 1; do 
            # a pouze pro rozliseni, ktere je vetsi
            name=$(basename "$innerPath" | sed -E "s/${sourceResolution}/${newResolution}K/g")
            newResolutionFolder="${newResolution}K"
            if [ "${sourceResolution/K/}" -gt "$newResolution" ]; then
                # vytvorime slozku pro nove rozliseni
                mkdir -p "${newResolutionFolder}"
                # a pro kazdy obrazek, ktery existuje ve slozce s nejvyssim rozlisenim vygenerujeme nasobek 1K
                find ${sourceResolution} -name "*.jpg" -or -name "*.jpeg" -or -name "*.tif" -or -name "*.tiff" -or -name "*.png" | while read currentFile; do
                    newFile=$(sed -E "s/${sourceResolution}/${newResolutionFolder}/" <<<"${currentFile}")
                    newFile=$(sed -E "s/${sourceResolution}/${newResolution}K/" <<<"${newFile}")
                    newFile=$(echo $newFile | xargs)
                    echo "${currentFile} -> ${newFile}" >> "${logPath}"
                    pixels=$((1024*${newResolution}))
                    # a tohle je prikaz, ktery to realne udela
                    timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${currentFile}" -resize ${pixels}x${pixels} "${newFile}" || timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${currentFile}" -resize ${pixels}x${pixels} "${newFile}" || timeout 3m "${IMAGEMAGICK_PATH}" convert -quiet "${currentFile}" -resize ${pixels}x${pixels} "${newFile}" || (echo "!!! ${newFile} did not get generated" && echo "!!! ${newFile} did not get generated" >> "${logPath}"); 
                done
                echo -n "${newResolution}K... "
            fi
        done
        # nakonec, kdyz mame vsechna rozliseni, vygenerujeme metadata tou funkci nahore
        genMetadata >metadata.json
        # a vytvorime archivy pro vsechna existujici rozliseni
        echo -n "Archival... "
        for i in $(find . -type d -name '*K'); do 
            newResolution="${i/.\//}"
            name=$(basename "$innerPath" | sed -E "s/${sourceResolution}/${newResolution}/g")
            newResolutionFolder="${newResolution}"
            mkdir -p "${name}_${newResolution}"
            cp -r PREVIEW metadata.json "${name}_${newResolution}"
            mv "${newResolutionFolder}" "${name}_${newResolution}"
            find "${name}_${newResolution}" -exec touch -t 202601010000 {} +
            "${ZIP_PATH}" -r "${name}_${newResolution}.zip" "${name}_${newResolution}" >>"${logPath}"
            rm -fr "${name}_${newResolution}"
        done
        echo "Done"
    # vystoupi ven ze slozky nahore
    popd >/dev/null
done